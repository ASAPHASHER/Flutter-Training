import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './contact.html',
  styleUrl: './contact.css',
  // animations: []
})
export class Contact {
  contactForm = {
    name: '',
    email: '',
    message: ''
  };
  submitted = false;

  onSubmit() {
    this.submitted = true;
    setTimeout(() => this.submitted = false, 3000);
    this.contactForm = { name: '', email: '', message: '' };
  }

  institution = {
    name: 'EduInstitute',
    address: '123 Knowledge Avenue, City, State, 123456',
    phone: '+91 98765 43210',
    email: 'info@eduinstitute.edu',
    map: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.019123456789!2d77.5946!3d12.9716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0:0x0!2zMTLCsDU4JzE3LjgiTiA3N8KwMzUnNDEuNiJF!5e0!3m2!1sen!2sin!4v1710000000000!5m2!1sen!2sin'
  };
}
