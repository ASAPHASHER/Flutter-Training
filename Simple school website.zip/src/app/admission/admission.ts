import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-admission',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admission.html',
  styleUrl: './admission.css',
  // animations: []
})
export class Admission {
  submitted = false;
  submittedData: any = null;
  form;

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      dob: ['', Validators.required],
      class: ['', Validators.required],
      parent: ['', Validators.required],
      contact: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      email: ['', [Validators.required, Validators.email]],
      address: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.form.valid) {
      this.submitted = true;
      this.submittedData = this.form.value;
      this.form.reset();
      setTimeout(() => this.submitted = false, 3000);
    }
  }
}
