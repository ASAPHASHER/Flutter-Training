import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Teacher {
  name: string;
  subject: string;
  qualification: string;
  photo: string;
  bio: string;
}

@Component({
  selector: 'app-teachers',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './teachers.html',
  styleUrl: './teachers.css',
  // animations: []
})
export class Teachers {
  filter = '';
  teachers: Teacher[] = [
    {
      name: 'Dr. Charlotte Smith',
      subject: 'Mathematics',
      qualification: 'PhD, M.Sc. Mathematics',
      photo: 'https://randomuser.me/api/portraits/women/50.jpg',
      bio: '15+ years of teaching experience. Loves making math fun and accessible.'
    },
    {
      name: 'Mr. Oliver Johnson',
      subject: 'Physics',
      qualification: 'M.Sc. Physics, B.Ed.',
      photo: 'https://randomuser.me/api/portraits/men/51.jpg',
      bio: 'Passionate about experiments and real-world science.'
    },
    {
      name: 'Ms. Amelia Brown',
      subject: 'English',
      qualification: 'MA English, B.Ed.',
      photo: 'https://randomuser.me/api/portraits/women/52.jpg',
      bio: 'Focuses on creative writing and communication skills.'
    },
    {
      name: 'Mr. George Wilson',
      subject: 'Chemistry',
      qualification: 'M.Sc. Chemistry, NET',
      photo: 'https://randomuser.me/api/portraits/men/53.jpg',
      bio: 'Specializes in organic chemistry and lab safety.'
    },
    {
      name: 'Mrs. Emily Taylor',
      subject: 'Biology',
      qualification: 'M.Sc. Botany, B.Ed.',
      photo: 'https://randomuser.me/api/portraits/women/54.jpg',
      bio: 'Loves field trips and nature studies.'
    },
    {
      name: 'Mr. Harry Davies',
      subject: 'Mathematics',
      qualification: 'M.Sc. Mathematics, B.Ed.',
      photo: 'https://randomuser.me/api/portraits/men/55.jpg',
      bio: 'Enjoys problem-solving and math olympiads.'
    }
  ];

  get subjects() {
    return Array.from(new Set(this.teachers.map(t => t.subject)));
  }

  get filteredTeachers() {
    const term = this.filter.trim().toLowerCase();
    if (!term) return this.teachers;
    return this.teachers.filter(t => t.subject.toLowerCase().includes(term));
  }
}
