import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Student {
  name: string;
  rollNumber: string;
  class: string;
  photo: string;
  attendance: number;
}

@Component({
  selector: 'app-students',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './students.html',
  styleUrl: './students.css',
  // animations: []
})
export class Students {
  search = '';
  students: Student[] = [
    {
      name: 'James Thompson',
      rollNumber: 'S101',
      class: '10A',
      photo: 'https://randomuser.me/api/portraits/men/32.jpg',
      attendance: 96
    },
    {
      name: 'Sophie Evans',
      rollNumber: 'S102',
      class: '10A',
      photo: 'https://randomuser.me/api/portraits/women/44.jpg',
      attendance: 98
    },
    {
      name: 'William Clark',
      rollNumber: 'S103',
      class: '9B',
      photo: 'https://randomuser.me/api/portraits/men/45.jpg',
      attendance: 92
    },
    {
      name: 'Emily Walker',
      rollNumber: 'S104',
      class: '8C',
      photo: 'https://randomuser.me/api/portraits/women/65.jpg',
      attendance: 99
    },
    {
      name: 'George Harris',
      rollNumber: 'S105',
      class: '10A',
      photo: 'https://randomuser.me/api/portraits/men/76.jpg',
      attendance: 94
    },
    {
      name: 'Olivia Lewis',
      rollNumber: 'S106',
      class: '9B',
      photo: 'https://randomuser.me/api/portraits/women/23.jpg',
      attendance: 97
    }
  ];

  get filteredStudents() {
    const term = this.search.trim().toLowerCase();
    if (!term) return this.students;
    return this.students.filter(s =>
      s.name.toLowerCase().includes(term) ||
      s.rollNumber.toLowerCase().includes(term) ||
      s.class.toLowerCase().includes(term)
    );
  }
}
