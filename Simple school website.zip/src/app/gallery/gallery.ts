import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface GalleryItem {
  image: string;
  title: string;
  caption: string;
}

@Component({
  selector: 'app-gallery',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './gallery.html',
  styleUrl: './gallery.css'
})
export class Gallery {
  items: GalleryItem[] = [
    {
      image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80',
      title: 'Annual Science Fair',
      caption: 'Students showcase their innovative projects and experiments.'
    },
    {
      image: 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=600&q=80',
      title: 'Sports Day',
      caption: 'A day of fun, fitness, and friendly competition.'
    },
    {
      image: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=600&q=80',
      title: 'Art & Culture Fest',
      caption: 'Celebrating creativity and cultural diversity.'
    },
    {
      image: 'https://images.unsplash.com/photo-1503676382389-4809596d5290?auto=format&fit=crop&w=600&q=80',
      title: 'Graduation Ceremony',
      caption: 'Honoring the achievements of our graduating students.'
    },
    {
      image: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=600&q=80',
      title: 'Field Trip',
      caption: 'Exploring and learning beyond the classroom.'
    },
    {
      image: 'https://images.unsplash.com/photo-1515168833906-d2a3b82b3029?auto=format&fit=crop&w=600&q=80',
      title: 'Robotics Workshop',
      caption: 'Hands-on learning with the latest technology.'
    }
  ];

  lightboxOpen = false;
  selectedIndex = 0;

  openLightbox(index: number) {
    this.selectedIndex = index;
    this.lightboxOpen = true;
    document.body.style.overflow = 'hidden';
  }

  closeLightbox() {
    this.lightboxOpen = false;
    document.body.style.overflow = '';
  }

  prevImage() {
    this.selectedIndex = (this.selectedIndex - 1 + this.items.length) % this.items.length;
  }

  nextImage() {
    this.selectedIndex = (this.selectedIndex + 1) % this.items.length;
  }

  get selectedItem() {
    return this.items[this.selectedIndex];
  }
}
