import { Routes } from '@angular/router';
import { Home } from './home/home';
import { Students } from './students/students';
import { Teachers } from './teachers/teachers';
import { Admission } from './admission/admission';
import { Contact } from './contact/contact';
import { Gallery } from './gallery/gallery';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'students', component: Students },
  { path: 'teachers', component: Teachers },
  { path: 'admission', component: Admission },
  { path: 'contact', component: Contact },
  { path: 'gallery', component: Gallery },
  { path: '**', redirectTo: '' },
];
